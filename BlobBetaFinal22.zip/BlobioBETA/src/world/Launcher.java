package world;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

public class Launcher {
	public static void main(String[] args) {
		// Creates and calls the menu class
		MenuGame arena = new MenuGame();
		LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
		// Sets the height and width of the screen
		config.width = 1600;
		config.height = 900;
		LwjglApplication launcher = new LwjglApplication(arena, config);
	}

}
