package world;

import com.badlogic.gdx.Game;

public class MenuGame extends Game {

	// Creates and sets menu screen as the first thing to show up in the launcher
	public void create() {
		Menu menu = new Menu(this);
		setScreen(menu);
	}
}